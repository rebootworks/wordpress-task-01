<?php if (!defined('ABSPATH')) exit('No direct script access allowed');

// You can add some hooks related the shortcode in here.