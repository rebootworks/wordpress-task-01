<?php

if (!defined('ABSPATH')) {
    exit('No direct script access allowed');
}


if (!defined('EVCC_AGENCY')) {
    define('EVCC_AGENCY', 'Reboot');
}